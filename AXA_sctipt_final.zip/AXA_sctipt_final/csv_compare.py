import csv
 
f1=open(r"D:\csv\csv1.csv","rt")
data1=csv.reader(f1)
 
f2=open(r"D:\csv\csv2.csv","rt") 
data2=csv.reader(f2)
#row2 = next(data)
 
arr1 = [];
for sku in data:
    arr1.append(sku);
 
arr2 = [];
for sku in data2:
    arr2.append(sku);
 
lonely_sku = []
webshop_sku = {}
 
def gen(test):
    for sku in arr2:
        if sku[0] == test[0]:
            return sku;
 
for test in arr1:
    row = gen(test);
    if(row == None):
        lonely_sku.append(test[0])
    else:
        webshop_sku[row[0]] = (row[11])
 
price.close()
shop.close()
 
out=open(r"D:\csv\output.csv","wb")
output=csv.writer(out)
 
for key, value in webshop_sku.iteritems():
    data = key, value
    output.writerow(data)
 
out.close()
 
out_lonely=open("lonely_sku.csv","wb")
output_lonely=csv.writer(out_lonely)
 
for sku in lonely_sku:
    output_lonely.writerow([sku])
 
out_lonely.close()

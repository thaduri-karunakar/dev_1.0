import csv

csv1 = open('csv_1.csv')
csv2 = open('csv_2.csv')
csv3 = open('outfile.csv', 'w')

c1 = csv.reader(csv1)
c2 = csv.reader(csv2)
c3 = csv.writer(csv3)
#next(sheet1)
#next(sheet2)
#csv1 = next(sheet1)
#csv2 = next(sheet2)

#for file1 in sheet1:
    #print file1
    #for file2 in sheet2:
        #for file1[0] in file2[1]:
            #print file1[0]



masterlist = list(c1)

for hosts_row in c2:
    row = 1
    #print row
    found = False
    for master_row in masterlist:
        results_row = hosts_row
        #print results_row
        if hosts_row[0] == master_row[1]:
            results_row.append('FOUND in master list (row ' + str(row) + ')')
            found = True
            #print row
            break
        row = row + 1
    if not found:
        results_row.append('NOT FOUND in master list')
    c3.writerow(results_row)
    
         
    
     
csv1.close()
csv2.close()
csv3.close()

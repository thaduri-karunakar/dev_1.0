import elasticsearch
import unicodedata
import csv
import json
es = elasticsearch.Elasticsearch(["banvi14-i198126:9200"])
# this returns up to 500 rows, adjust to your needs
#res = es.search("select * from ao_itoa_alarms_uim_1_1 where domain = Ravi_Domain")
res = es.search(index="ao_itoa_alarms_uim_1_1", body=
                {
                    "_source": ["subsystemID","subsystem","source","robot","nimid","host","metric_type","met_id",
                                "level","ip","ci_id","domain","custom_1","metric_unit","custom_5","origin",
                                "custom_4","supp_key","ci_type","metric_name","severity","cs_id","ci_name",
                                "metric_value","message","probe","dev_id","user_tag2","hub","user_tag1","tenant_id","custom_3","custom_2"],
                    "query": {
                        "term": {
                            "domain": {
                                "value": "axagateway_domain"                            
                        }
                    }
                        }
}, size=1000)
for doc in res['hits']['hits']:
    print doc
with open('mycsvfile.csv', 'w') as f:  # Just use 'w' mode in 3.x
    header_present  = False
    for doc in res['hits']['hits']:
        my_dict = doc['_source'] 
        if not header_present:
            w = csv.DictWriter(f, my_dict.keys())
            w.writeheader()
            header_present = True
        w.writerow(my_dict)


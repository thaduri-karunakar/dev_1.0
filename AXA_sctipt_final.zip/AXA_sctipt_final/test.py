import pymssql
import csv
import os,sys

####################################################### SQL Connection  ##################################################

conn = pymssql.connect(server='10.238.245.11', user='sa', password='t3sti9', database='CA_UIM_Karunakar')
cursor = conn.cursor()

####################################################### Getting data from table ##################################################
cursor.execute('''select * from nas_alarms''')


#tables = cursor.fetchall()
row = cursor.fetchall()
conn.close()
print(row)
print("done")

import elasticsearch
import unicodedata
import csv
import json
file = open(r'D:\csv\outputfile.json')
file_load = json.load(file)

file.close()

file1 = open(r'D:\csv\outputfile.csv','w+')
file_write = csv.writer(file1)
file_write.writerow(file_load)
file1.close()
print (file_load)


# Create a DataFrame object
import pandasticsearch
import requests
from pandasticsearch import DataFrame
df = DataFrame.from_es(url='http://banvi14-i198126:9200', index='ao_itoa_alarms_uim_1_1')

# Print the schema(mapping) of the index
df.print_schema()
# company
# |-- employee
#   |-- name: {'index': 'not_analyzed', 'type': 'string'}
#   |-- age: {'type': 'integer'}
#   |-- gender: {'index': 'not_analyzed', 'type': 'string'}

# Inspect the columns
df.columns
#['name', 'age', 'gender']

# Inspect the columns
df.columns
#['name', 'age', 'gender']

# Denote a column
df.level
# Column('name')
df['domain']
# Column('age')

# Projection
df.filter(df.level < 25).select('domain', 'level').collect()
# [Row(age=12,name='Alice'), Row(age=11,name='Bob'), Row(age=13,name='Leo')]

# Print the rows into console
df.filter(df.level < 25).select('domain').show(3)
# +------+
# | name |
# +------+
# | Alice|
# | Bob  |
# | Leo  |
# +------+


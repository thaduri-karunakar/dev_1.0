def a():
    print "aaa"
a()

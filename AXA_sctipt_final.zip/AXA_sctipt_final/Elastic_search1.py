import elasticsearch
import unicodedata
import csv
import json
#es = elasticsearch.Elasticsearch(["banvi14-i198126:9200"])
# this returns up to 500 rows, adjust to your needs
#res = es.search("select * from ao_itoa_alarms_uim_1_1 where domain = Ravi_Domain")
#res = es.search(index="ao_itoa_alarms_uim_1_1", body={"query": {"term": {"domain": {"value": "axagateway_domain"}}}})
#sample = res['hits']['hits']
# then open a csv file, and loop through the results, writing to the csv


#with open(r'D:\Python27\AXA_Script\axa_csv1.json', 'w+') as outfile:
    #json.dump(sample, outfile)


#outfile.close()
with open(r'D:\Python27\AXA_Script\axa_csv1.json') as json_file:
    data = json.load(json_file)
    




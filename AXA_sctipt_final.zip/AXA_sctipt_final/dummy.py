import pymssql
import csv
import os,sys


conn = pymssql.connect(server='10.112.78.172', user='sa', password='India@123', database='CA_UIM_Karunakar_851')
cursor = conn.cursor()
cursor.execute('''SELECT level from nas_alarms''')     
row = cursor.fetchall()
conn.close()


c_name = [i[0] for i in cursor.description]
#print (c_name)






c1 =open(r'D:\db1.csv', 'rb')
c2 =open(r'D:\db2.csv', 'wb') 
writer = csv.writer(c2)

writer.writerow(next(c1)+"{}".format(c_name))
c1.close()
c2.close()




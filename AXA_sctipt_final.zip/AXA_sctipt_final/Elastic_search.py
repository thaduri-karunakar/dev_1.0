from elasticsearch import Elasticsearch
import requests
import csv
import json
es = Elasticsearch(['http://banvi14-i198126:9200'])
row = es.search(index="ao_itoa_alarms_uim_1_1", body={"query": {
        "term": {
           "domain": {
              "value": "Ravi_Domain"
           }
        }
            
        
    }})
f2 = open(r'D:\csv\ela1.json','w')
for r in row:
    writer = csv.writer(f2)
    writer.writerows(row)
f2.close()

print (row)

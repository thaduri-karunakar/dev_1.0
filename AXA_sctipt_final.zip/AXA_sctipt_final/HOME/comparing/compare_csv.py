import csv
import codecs
csv1 = open(r'AXA_ALARM.csv','rb')
csv2 = open(r'UIM_ALARM.csv','rb')



c1 = csv.reader(csv1)
c2 = csv.reader(csv2)

next (c1)
#print c1
#c1= list(c1)
#print c1
next (c2)

#c2= list(c2)
#print c2

##print  c1
##print "========================================================================"
##print c2
list_file = []
iteration_count = 1
for line in c1:
    
    #print line
    for line1 in c2:
        
        if line[3] == line1[3]:
            
            #print  (" {}   matching with {}   ".format(line[0],line1[1]))
            #print line[3] + "  " + line1[3]
            res0 = cmp (line[0],line1[0])
            res1 = cmp (line[1],line1[1])
            res2 = cmp (line[2],line1[2]) 
            res3 = cmp (line[4],line1[4])
            res4 = cmp (line[5],line1[5])
            res5 = cmp (line[6],line1[6])
            res6 = cmp (line[7],line1[7])
            res7 = cmp (line[8],line1[8])
            res8 = cmp (line[9],line1[9])
            res9 = cmp (line[10],line1[10])
            res10 = cmp (line[11],line1[11])
            res11 = cmp (line[12],line1[12])
            res12 = cmp (line[13],line1[13])
            res13 = cmp (line[14],line1[14])
            res14 = cmp (line[15],line1[15])
            res15 = cmp (line[16],line1[16])
            res16 = cmp (line[17],line1[17])
            res17 = cmp (line[18],line1[18])
            res18 = cmp (line[19],line1[19])
            res19 = cmp (line[20],line1[20])
            res20 = cmp (line[21],line1[21])
            res21 = cmp (line[22],line1[22])
            res22 = cmp (line[23],line1[23])
            res23 = cmp (line[24],line1[24])
            res24 = cmp (line[25],line1[25])

            print ('''{} , {} , {} , {} , {} , {} , {} , {} , {} , {} ,
            {} , {} , {} , {} , {} , {} , {} , {} , {} , {} , {} ,
            {} , {} , {}'''.format(res0,res1,res2,res3,res4,res5,res6,res7,
            res8,res9,res10,res11,res12,res13,res14,res15,res16,res17,res18,res19,res20,res21,res22,res23,res24))
            print "=================================================================================="
            print ("{}, {} csv1 line is matching with {}----------   for iteration_count is : {}   ".format(res4,line[5],line1[5],iteration_count))
            print ("{}, {} csv1 line is matching with {}----------   for iteration_count is : {}   ".format(res5,line[6],line1[6],iteration_count))
            print ("{}, {} csv1 line is matching with {}----------   for iteration_count is : {}   ".format(res21,line[22],line1[22],iteration_count))
            print "=================================================================================="
            iteration_count += 1
            #print ("{}, {} csv1 line is matching with {} ".format(res,line[0],line[0]))
            #print res1
            
            
            
            if res4 == 0:
                
                #print "csv1 nimid column is : " + line[3] + " and csv2 nimid column is :  " + line1[3]
                break
            else:
                print ("not found line {}  in csv2 ".format(line[5],line1[5]))
                csv3 = open(r'outfile.csv', 'ab')
                writer = csv.writer(csv3)
                writer.writerow(["{} not in{} ".format(line[5],line1[5])])
                csv3.close()
                break
                
        else:
            print "======================================================="
            print ("not found line {}  in csv2 ".format(line[3],))

               
csv1.close()
csv2.close()
      
           

     
            
            
             
            
        
            
            

    
    





    
         
    


for x in xrange(10):
    for y in xrange(10):
        print x,y
        if x*y == 30:
            break
        
        else:
            continue
        break
    else:
        continue
    break
